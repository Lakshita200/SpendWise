THINGS TO DO WHEN YOU CLONE THE REPO
  - update the gitignore file to include ur venv name unless its already inside
  - pip install the requirements file
  - download postgres and follow the details in the .env file during password and name setting
